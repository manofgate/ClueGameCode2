package clueGame;

public class WalkwayCell extends BoardCell {
	@Override
	public boolean isWalkway() {
		return true;
	}
	
	

}
