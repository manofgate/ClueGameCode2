package clueGame;

import java.util.List;

public class HumanPlayer extends Player {

	public HumanPlayer() {
		super();
	}
	
	public HumanPlayer(List<Card> myCards) {
		super(myCards);
	}
	
}
