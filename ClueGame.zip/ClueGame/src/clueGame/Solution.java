package clueGame;

public class Solution {

	public final String person, weapon, room;
	
	public Solution(String person, String weapon, String room) {
		this.person = person;
		this.weapon = weapon;
		this.room = room;
	}

}
